#include "mq.h"

void consumer(MQ& mq);

