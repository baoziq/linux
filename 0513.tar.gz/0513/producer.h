#include "mq.h"
void producer(MQ& mq);
